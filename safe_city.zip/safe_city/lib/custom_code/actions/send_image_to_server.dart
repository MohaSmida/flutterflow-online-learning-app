// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!
import 'dart:convert';
import 'package:http/http.dart' as http;

Future<String> sendImageToServer(FFUploadedFile? imagePath) async {
  try {
    // Validate image
    if (imagePath == null ||
        imagePath.bytes == null ||
        imagePath.bytes!.isEmpty) {
      return 'Error: No image provided';
    }

    // Create a multipart request
    var request = http.MultipartRequest(
      'POST',
      Uri.parse('https://79a6-165-51-44-252.ngrok-free.app/upload'),
    );

    // Add the image file from bytes
    request.files.add(http.MultipartFile.fromBytes(
      'image',
      imagePath.bytes!,
      filename: imagePath.name ?? 'image.jpg',
    ));

    // Send the request
    var response = await request.send();
    var responseBody = await response.stream.bytesToString();

    // Handle the response
    if (response.statusCode == 200) {
      // Parse JSON response
      try {
        final data = jsonDecode(responseBody);
        return data['ingredients'] ?? 'No ingredients found';
      } catch (e) {
        return 'Error: Invalid response format';
      }
    } else {
      // Parse error response
      try {
        final data = jsonDecode(responseBody);
        return 'Error: ${response.statusCode} - ${data['error'] ?? responseBody}';
      } catch (e) {
        return 'Error: ${response.statusCode} - $responseBody';
      }
    }
  } catch (e) {
    return 'Error: $e';
  }
}
