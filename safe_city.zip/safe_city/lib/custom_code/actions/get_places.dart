// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:convert';
import 'package:http/http.dart' as http;

Future<List<dynamic>> getPlaces(
  String searchQuery,
  String accessToken,
) async {
  String encodedQuery = Uri.encodeFull(searchQuery);
  final response = await http.get(
      Uri.parse(
          'https://api.mapbox.com/search/geocode/v6/forward?q=$encodedQuery?&access_token=$accessToken'),
      headers: {
        'Authorization': 'Bearer $accessToken',
        'Content-type': 'application/json'
      });
  if (response.statusCode == 200) {
    print("direction recieved successfuly");
    final Map<String, dynamic> jsonResponse = json.decode(response.body);
    final List<dynamic> features = jsonResponse['features'];
    if (features.isEmpty) {
      print("not found");
      return [
        {'place_formatted': 'no places found'}
      ];
    } else {
      print("features");
      return features;
    }
  } else {
    print("error calculating direction : ${response.statusCode}");
    print("Response body : ${response.body}");
    return [
      {'place_formatted': 'no places found'}
    ];
  }
}
