// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:http/http.dart' as http;
import 'dart:convert';

Future<void> smssend(String to, String message) async {
  final String accountSid = 'AC6729a640ea5b14665bb8325027107c72';
  final String authToken = 'd25542de789cc2719ec96f1bfb051d87';
  final String twilioNumber = '+16075368519';

  final String url =
      'https://api.twilio.com/2010-04-01/Accounts/$accountSid/Messages.json';

  final response = await http.post(
    Uri.parse(url),
    headers: {
      'Authorization':
          'Basic ' + base64Encode(utf8.encode('$accountSid:$authToken')),
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: {
      'To': to,
      'From': twilioNumber,
      'Body': message,
    },
  );

  if (response.statusCode == 201 || response.statusCode == 200) {
    print('✅ SMS envoyé avec succès');
  } else {
    print('❌ Erreur: ${response.body}');
  }
}
