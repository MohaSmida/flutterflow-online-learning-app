// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/custom_code/actions/index.dart'; // Imports custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart' as ll;

class DynamicMap extends StatefulWidget {
  const DynamicMap({
    super.key,
    this.width,
    this.height,
    this.points,
    this.startingPoint,
    this.accessToken,
    this.startingZoom,
    this.markerPosition,
  });

  final double? width;
  final double? height;
  final List<LatLng>? points;
  final LatLng? startingPoint;
  final String? accessToken;
  final double? startingZoom;
  final LatLng? markerPosition;

  @override
  State<DynamicMap> createState() => _DynamicMapState();
}

class _DynamicMapState extends State<DynamicMap> {
  final _mapController = MapController();
  final List<Marker> mark = [];

  @override
  void initState() {
    super.initState();
    addInitialMarker();
  }

  List<Marker> addMarkersToMap(List<LatLng>? points) {
    List<Marker> allMarkers = [];

    for (LatLng point in points!) {
      allMarkers.add(
        Marker(
          point: ll.LatLng(point.latitude, point.longitude),
          width: 40,
          height: 40,
          child: const Icon(
            Icons.location_pin,
            color: Colors.red,
            size: 40,
          ),
        ),
      );
    }

    _mapController.move(
      ll.LatLng(points.last.latitude, points.last.longitude),
      8,
    );

    return allMarkers;
  }

  void addInitialMarker() {
    if (widget.markerPosition != null) {
      mark.add(
        Marker(
          point: ll.LatLng(
            widget.markerPosition!.latitude,
            widget.markerPosition!.longitude,
          ),
          width: 40,
          height: 40,
          child: const Icon(
            Icons.location_pin,
            color: Colors.blue,
            size: 40,
          ),
        ),
      );
    } else {
      mark.add(
        Marker(
          point: ll.LatLng(
            36.822748,
            10.306951,
          ),
          width: 40,
          height: 40,
          child: const Icon(
            Icons.location_pin,
            color: Colors.blue,
            size: 40,
          ),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return FlutterMap(
      mapController: _mapController,
      options: MapOptions(
        center: ll.LatLng(
          widget.startingPoint?.latitude ?? 36.822748,
          widget.startingPoint?.longitude ?? 10.306951,
        ),
        zoom: widget.startingZoom ?? 13,
        onTap: (_, __) {},
      ),
      children: [
        TileLayer(
          urlTemplate: 'https://cdn.lima-labs.com/{z}/{x}/{y}.png?api=demo',
        ),
        MarkerLayer(
          markers: FFAppState().testPlaces.isNotEmpty
              ? addMarkersToMap(FFAppState().testPlaces)
              : mark,
        ),
      ],
    );
  }
}
