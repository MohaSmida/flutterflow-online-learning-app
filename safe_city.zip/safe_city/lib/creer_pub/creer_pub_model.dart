import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import '/custom_code/actions/index.dart' as actions;
import '/index.dart';
import 'creer_pub_widget.dart' show CreerPubWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class CreerPubModel extends FlutterFlowModel<CreerPubWidget> {
  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // State field(s) for type widget.
  String? typeValue;
  FormFieldController<String>? typeValueController;
  bool isDataUploading_uploadDataN9q = false;
  FFUploadedFile uploadedLocalFile_uploadDataN9q =
      FFUploadedFile(bytes: Uint8List.fromList([]));

  // Stores action output result for [Custom Action - sendImageToServer] action in Container widget.
  String? reponse;
  // Stores action output result for [Backend Call - API (upload Image to ImgBB)] action in Button widget.
  ApiCallResponse? apiResultapv;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
