import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_drop_down.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import 'modifier_pub_widget.dart' show ModifierPubWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ModifierPubModel extends FlutterFlowModel<ModifierPubWidget> {
  ///  State fields for stateful widgets in this page.

  final formKey = GlobalKey<FormState>();
  // State field(s) for contenu widget.
  FocusNode? contenuFocusNode;
  TextEditingController? contenuTextController;
  String? Function(BuildContext, String?)? contenuTextControllerValidator;
  String? _contenuTextControllerValidator(BuildContext context, String? val) {
    if (val == null || val.isEmpty) {
      return 'Contenu is required';
    }

    if (val.length < 10) {
      return 'minimum 10 caractere';
    }

    return null;
  }

  // State field(s) for type widget.
  String? typeValue;
  FormFieldController<String>? typeValueController;

  @override
  void initState(BuildContext context) {
    contenuTextControllerValidator = _contenuTextControllerValidator;
  }

  @override
  void dispose() {
    contenuFocusNode?.dispose();
    contenuTextController?.dispose();
  }
}
