// Export pages
export '/pages/home_page/home_page_widget.dart' show HomePageWidget;
export '/aw/sensibilisation_categ/sensibilisation_categ_widget.dart'
    show SensibilisationCategWidget;
export '/pages/creates/creates_widget.dart' show CreatesWidget;
export '/gest_ressources/add_document_page_admin/add_document_page_admin_widget.dart'
    show AddDocumentPageAdminWidget;
export '/aw/viewcategory/viewcategory_widget.dart' show ViewcategoryWidget;
export '/aw/add_a_w/add_a_w_widget.dart' show AddAWWidget;
export '/aw/view_a_w/view_a_w_widget.dart' show ViewAWWidget;
export '/list_forum/list_forum_widget.dart' show ListForumWidget;
export '/creer_forum/creer_forum_widget.dart' show CreerForumWidget;
export '/aw/list_pub/list_pub_widget.dart' show ListPubWidget;
export '/creer_pub/creer_pub_widget.dart' show CreerPubWidget;
export '/modifier_forum/modifier_forum_widget.dart' show ModifierForumWidget;
export '/modifier_pub/modifier_pub_widget.dart' show ModifierPubWidget;
export '/risk_zones/list_of_zones/list_of_zones_widget.dart'
    show ListOfZonesWidget;
export '/risk_zones/add_zone/add_zone_widget.dart' show AddZoneWidget;
export '/risk_zones/update_zone/update_zone_widget.dart' show UpdateZoneWidget;
export '/card_zone/card_zone_widget.dart' show CardZoneWidget;
export '/gestion_de_reclamations/form_reclamation/form_reclamation_widget.dart'
    show FormReclamationWidget;
export '/feedbacksevaluations/feedback_list_page/feedback_list_page_widget.dart'
    show FeedbackListPageWidget;
export '/feedbacksevaluations/feedback_detail_page/feedback_detail_page_widget.dart'
    show FeedbackDetailPageWidget;
export '/feedbacksevaluations/add_feedback_page/add_feedback_page_widget.dart'
    show AddFeedbackPageWidget;
export '/gestion_de_reclamations/reclamations_admin_dashboard/reclamations_admin_dashboard_widget.dart'
    show ReclamationsAdminDashboardWidget;
export '/aw/update_a_w/update_a_w_widget.dart' show UpdateAWWidget;
export '/aw/view_a_w_client/view_a_w_client_widget.dart'
    show ViewAWClientWidget;
export '/gest_ressources/documents_home_page_admin/documents_home_page_admin_widget.dart'
    show DocumentsHomePageAdminWidget;
export '/aw/viewcategory_client/viewcategory_client_widget.dart'
    show ViewcategoryClientWidget;
export '/gest_ressources/documents_home_page/documents_home_page_widget.dart'
    show DocumentsHomePageWidget;
export '/gest_ressources/update_document_page_admin/update_document_page_admin_widget.dart'
    show UpdateDocumentPageAdminWidget;
export '/pages/login2/login2_widget.dart' show Login2Widget;
export '/feedbacksevaluations/listcategories/listcategories_widget.dart'
    show ListcategoriesWidget;
export '/feedbacksevaluations/addcategory/addcategory_widget.dart'
    show AddcategoryWidget;
export '/feedbacksevaluations/editcategory/editcategory_widget.dart'
    show EditcategoryWidget;
export '/pages/home_page_admin/home_page_admin_widget.dart'
    show HomePageAdminWidget;
export '/pages/home_page_user/home_page_user_widget.dart'
    show HomePageUserWidget;
export '/risk_zones/map_add_page/map_add_page_widget.dart'
    show MapAddPageWidget;
export '/idea_box/idea_box_add/idea_box_add_widget.dart' show IdeaBoxAddWidget;
export '/idea_box/idea_list/idea_list_widget.dart' show IdeaListWidget;
export '/risk_zones/details_zone/details_zone_widget.dart'
    show DetailsZoneWidget;
export '/risk_zones/modify_zone/modify_zone_widget.dart' show ModifyZoneWidget;
export '/risk_zones/map_modify_page/map_modify_page_widget.dart'
    show MapModifyPageWidget;
export '/aw/add_a_w_copy/add_a_w_copy_widget.dart' show AddAWCopyWidget;
export '/gest_ressources/translate_document/translate_document_widget.dart'
    show TranslateDocumentWidget;
export '/aw/apdfview/apdfview_widget.dart' show ApdfviewWidget;
export '/idea_box/idea_boxupdate/idea_boxupdate_widget.dart'
    show IdeaBoxupdateWidget;
export '/gest_ressources/favorite_document/favorite_document_widget.dart'
    show FavoriteDocumentWidget;
export '/idea_box/idea_list_user/idea_list_user_widget.dart'
    show IdeaListUserWidget;
