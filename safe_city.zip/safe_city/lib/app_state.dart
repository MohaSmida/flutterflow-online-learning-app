import 'package:flutter/material.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/api_requests/api_manager.dart';
import 'backend/supabase/supabase.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  String _pdfpath = '';
  String get pdfpath => _pdfpath;
  set pdfpath(String value) {
    _pdfpath = value;
  }

  String _imageUrl = '';
  String get imageUrl => _imageUrl;
  set imageUrl(String value) {
    _imageUrl = value;
  }

  String _resultResponse = '';
  String get resultResponse => _resultResponse;
  set resultResponse(String value) {
    _resultResponse = value;
  }

  List<LatLng> _testPlaces = [];
  List<LatLng> get testPlaces => _testPlaces;
  set testPlaces(List<LatLng> value) {
    _testPlaces = value;
  }

  void addToTestPlaces(LatLng value) {
    testPlaces.add(value);
  }

  void removeFromTestPlaces(LatLng value) {
    testPlaces.remove(value);
  }

  void removeAtIndexFromTestPlaces(int index) {
    testPlaces.removeAt(index);
  }

  void updateTestPlacesAtIndex(
    int index,
    LatLng Function(LatLng) updateFn,
  ) {
    testPlaces[index] = updateFn(_testPlaces[index]);
  }

  void insertAtIndexInTestPlaces(int index, LatLng value) {
    testPlaces.insert(index, value);
  }

  bool _pointClicked = false;
  bool get pointClicked => _pointClicked;
  set pointClicked(bool value) {
    _pointClicked = value;
  }

  double _latt = 0.0;
  double get latt => _latt;
  set latt(double value) {
    _latt = value;
  }

  double _long = 0.0;
  double get long => _long;
  set long(double value) {
    _long = value;
  }

  String _resquery = '';
  String get resquery => _resquery;
  set resquery(String value) {
    _resquery = value;
  }
}
