import 'dart:convert';
import 'dart:typed_data';
import '../schema/structs/index.dart';

import 'package:flutter/foundation.dart';

import '/flutter_flow/flutter_flow_util.dart';
import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

/// Start FlutterFlow + PDF ApiFlow API Group Code

class FlutterFlowPDFApiFlowAPIGroup {
  static String getBaseUrl() =>
      'https://gw.apiflow.online/api/edbf75123de1413c8e0ea0332f85d7ac';
  static Map<String, String> headers = {
    'Authorization':
        'Bearer OTNmNDBlMmY3MTgwZmY4NWI4MzgwMGViMjg4ZmQ5YTA6ODFkMjljNDFlMTU1MGUwYTYyM2IyMGExY2Y2M2VjZmM=',
  };
  static GeneratePDFCall generatePDFCall = GeneratePDFCall();
}

class GeneratePDFCall {
  Future<ApiCallResponse> call({
    String? nameA = '',
    String? category = '',
  }) async {
    final baseUrl = FlutterFlowPDFApiFlowAPIGroup.getBaseUrl();

    final ffApiRequestBody = '''
{
  "nameA": "${escapeStringForJson(nameA)}",
  "category": "${escapeStringForJson(category)}"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Generate PDF',
      apiUrl: '${baseUrl}/generate?nameA=${nameA}&category=${category}',
      callType: ApiCallType.POST,
      headers: {
        'Authorization':
            'Bearer OTNmNDBlMmY3MTgwZmY4NWI4MzgwMGViMjg4ZmQ5YTA6ODFkMjljNDFlMTU1MGUwYTYyM2IyMGExY2Y2M2VjZmM=',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

/// End FlutterFlow + PDF ApiFlow API Group Code

class UploadImageToImgBBCall {
  static Future<ApiCallResponse> call({
    FFUploadedFile? image,
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'upload Image to ImgBB',
      apiUrl:
          'https://api.imgbb.com/1/upload?key=e65256ebf6d47856a83664be277af4e9',
      callType: ApiCallType.POST,
      headers: {},
      params: {
        'image': image,
      },
      bodyType: BodyType.MULTIPART,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  static dynamic imageUrl(dynamic response) => getJsonField(
        response,
        r'''$.data.url''',
      );
}

class SearchAWCall {
  static Future<ApiCallResponse> call({
    String? searchString = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'search AW',
      apiUrl:
          'https://stgxbjopfrtpglhyjdml.supabase.co/rest/v1/awareness?nameA=ilike.*${searchString}*&select=*\'',
      callType: ApiCallType.GET,
      headers: {
        'apikey':
            'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN0Z3hiam9wZnJ0cGdsaHlqZG1sIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDYxMTQ1MTEsImV4cCI6MjA2MTY5MDUxMX0.HDBoBrFBMVexipHrFGzjPHI1VtOBzj_1L_7UqpFUax8',
        'Authorization':
            'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN0Z3hiam9wZnJ0cGdsaHlqZG1sIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDYxMTQ1MTEsImV4cCI6MjA2MTY5MDUxMX0.HDBoBrFBMVexipHrFGzjPHI1VtOBzj_1L_7UqpFUax8',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class CategoryCallCall {
  static Future<ApiCallResponse> call({
    String? searchString = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'categoryCall',
      apiUrl:
          'https://stgxbjopfrtpglhyjdml.supabase.co/rest/v1/awareness?categorys=ilike.*${searchString}*&select=*\'',
      callType: ApiCallType.GET,
      headers: {
        'Authorization':
            'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN0Z3hiam9wZnJ0cGdsaHlqZG1sIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDYxMTQ1MTEsImV4cCI6MjA2MTY5MDUxMX0.HDBoBrFBMVexipHrFGzjPHI1VtOBzj_1L_7UqpFUax8',
        'apikey':
            'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN0Z3hiam9wZnJ0cGdsaHlqZG1sIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDYxMTQ1MTEsImV4cCI6MjA2MTY5MDUxMX0.HDBoBrFBMVexipHrFGzjPHI1VtOBzj_1L_7UqpFUax8',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ReverseGeoCodeCall {
  static Future<ApiCallResponse> call({
    String? lat = '0.0',
    String? lon = '0.0',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'ReverseGeoCode',
      apiUrl:
          'https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=LAT&longitude=LON&localityLanguage=en',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class RevvgeoCall {
  static Future<ApiCallResponse> call({
    String? lat = '0.0',
    String? lon = '0.0',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'revvgeo',
      apiUrl:
          'https://api.bigdatacloud.net/data/reverse-geocode?latitude=LAT&longitude=LON&localityLanguage=en&key=bdc_d7dd989e0e8b4e6eb8056c2d903b80d8',
      callType: ApiCallType.GET,
      headers: {},
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _toEncodable(dynamic item) {
  if (item is DocumentReference) {
    return item.path;
  }
  return item;
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("List serialization failed. Returning empty list.");
    }
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("Json serialization failed. Returning empty json.");
    }
    return isList ? '[]' : '{}';
  }
}

String? escapeStringForJson(String? input) {
  if (input == null) {
    return null;
  }
  return input
      .replaceAll('\\', '\\\\')
      .replaceAll('"', '\\"')
      .replaceAll('\n', '\\n')
      .replaceAll('\t', '\\t');
}
