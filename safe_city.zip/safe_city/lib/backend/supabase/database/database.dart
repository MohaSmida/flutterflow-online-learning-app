export '../../../flutter_flow/lat_lng.dart';
export 'package:supabase_flutter/supabase_flutter.dart' hide Provider;

export '../supabase.dart';
export 'row.dart';
export 'table.dart';

export 'tables/documents_officiels.dart';
export 'tables/idea.dart';
export 'tables/categsensibilisation.dart';
export 'tables/reclamation.dart';
export 'tables/types_documents.dart';
export 'tables/awareness.dart';
export 'tables/idea_like_relation.dart';
export 'tables/feedbacks.dart';
export 'tables/users.dart';
export 'tables/risk_zones.dart';
