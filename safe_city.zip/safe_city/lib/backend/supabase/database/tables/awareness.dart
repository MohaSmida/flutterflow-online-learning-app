import '../database.dart';

class AwarenessTable extends SupabaseTable<AwarenessRow> {
  @override
  String get tableName => 'awareness';

  @override
  AwarenessRow createRow(Map<String, dynamic> data) => AwarenessRow(data);
}

class AwarenessRow extends SupabaseDataRow {
  AwarenessRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => AwarenessTable();

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get nameA => getField<String>('nameA');
  set nameA(String? value) => setField<String>('nameA', value);

  String? get imageUrlA => getField<String>('imageUrlA');
  set imageUrlA(String? value) => setField<String>('imageUrlA', value);

  String? get description => getField<String>('description');
  set description(String? value) => setField<String>('description', value);

  String? get categorys => getField<String>('categorys');
  set categorys(String? value) => setField<String>('categorys', value);
}
