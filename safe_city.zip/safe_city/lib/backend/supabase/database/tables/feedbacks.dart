import '../database.dart';

class FeedbacksTable extends SupabaseTable<FeedbacksRow> {
  @override
  String get tableName => 'feedbacks';

  @override
  FeedbacksRow createRow(Map<String, dynamic> data) => FeedbacksRow(data);
}

class FeedbacksRow extends SupabaseDataRow {
  FeedbacksRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => FeedbacksTable();

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);

  String? get userId => getField<String>('user_id');
  set userId(String? value) => setField<String>('user_id', value);

  String? get comment => getField<String>('comment');
  set comment(String? value) => setField<String>('comment', value);

  int? get rating => getField<int>('rating');
  set rating(int? value) => setField<int>('rating', value);

  DateTime? get createdAt => getField<DateTime>('created_at');
  set createdAt(DateTime? value) => setField<DateTime>('created_at', value);
}
