import '../database.dart';

class IdeaTable extends SupabaseTable<IdeaRow> {
  @override
  String get tableName => 'idea';

  @override
  IdeaRow createRow(Map<String, dynamic> data) => IdeaRow(data);
}

class IdeaRow extends SupabaseDataRow {
  IdeaRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => IdeaTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get title => getField<String>('title');
  set title(String? value) => setField<String>('title', value);

  String? get description => getField<String>('description');
  set description(String? value) => setField<String>('description', value);

  String? get imageUrl => getField<String>('imageUrl');
  set imageUrl(String? value) => setField<String>('imageUrl', value);

  String? get category => getField<String>('category');
  set category(String? value) => setField<String>('category', value);

  int? get likeCount => getField<int>('likeCount');
  set likeCount(int? value) => setField<int>('likeCount', value);

  String? get postedBy => getField<String>('posted_by');
  set postedBy(String? value) => setField<String>('posted_by', value);
}
