import '../database.dart';

class DocumentsOfficielsTable extends SupabaseTable<DocumentsOfficielsRow> {
  @override
  String get tableName => 'documents_officiels';

  @override
  DocumentsOfficielsRow createRow(Map<String, dynamic> data) =>
      DocumentsOfficielsRow(data);
}

class DocumentsOfficielsRow extends SupabaseDataRow {
  DocumentsOfficielsRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => DocumentsOfficielsTable();

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get titre => getField<String>('titre');
  set titre(String? value) => setField<String>('titre', value);

  String? get type => getField<String>('type');
  set type(String? value) => setField<String>('type', value);

  String? get categorie => getField<String>('categorie');
  set categorie(String? value) => setField<String>('categorie', value);

  String? get url => getField<String>('url');
  set url(String? value) => setField<String>('url', value);

  String? get uploadePar => getField<String>('uploade_par');
  set uploadePar(String? value) => setField<String>('uploade_par', value);

  String? get description => getField<String>('description');
  set description(String? value) => setField<String>('description', value);

  bool? get favorite => getField<bool>('favorite');
  set favorite(bool? value) => setField<bool>('favorite', value);
}
