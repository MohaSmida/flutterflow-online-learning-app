import '../database.dart';

class IdeaLikeRelationTable extends SupabaseTable<IdeaLikeRelationRow> {
  @override
  String get tableName => 'idea_like_relation';

  @override
  IdeaLikeRelationRow createRow(Map<String, dynamic> data) =>
      IdeaLikeRelationRow(data);
}

class IdeaLikeRelationRow extends SupabaseDataRow {
  IdeaLikeRelationRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => IdeaLikeRelationTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime? get createdAt => getField<DateTime>('created_at');
  set createdAt(DateTime? value) => setField<DateTime>('created_at', value);

  int get ideaId => getField<int>('idea_id')!;
  set ideaId(int value) => setField<int>('idea_id', value);

  String? get likedBy => getField<String>('liked_by');
  set likedBy(String? value) => setField<String>('liked_by', value);
}
