import '../database.dart';

class RiskZonesTable extends SupabaseTable<RiskZonesRow> {
  @override
  String get tableName => 'risk_zones';

  @override
  RiskZonesRow createRow(Map<String, dynamic> data) => RiskZonesRow(data);
}

class RiskZonesRow extends SupabaseDataRow {
  RiskZonesRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => RiskZonesTable();

  int get ideaId => getField<int>('idea_id')!;
  set ideaId(int value) => setField<int>('idea_id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get name => getField<String>('name');
  set name(String? value) => setField<String>('name', value);

  String? get description => getField<String>('description');
  set description(String? value) => setField<String>('description', value);

  String? get level => getField<String>('level');
  set level(String? value) => setField<String>('level', value);

  double? get latitude => getField<double>('latitude');
  set latitude(double? value) => setField<double>('latitude', value);

  double? get longitude => getField<double>('longitude');
  set longitude(double? value) => setField<double>('longitude', value);
}
