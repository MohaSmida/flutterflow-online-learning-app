import '../database.dart';

class CategsensibilisationTable extends SupabaseTable<CategsensibilisationRow> {
  @override
  String get tableName => 'categsensibilisation';

  @override
  CategsensibilisationRow createRow(Map<String, dynamic> data) =>
      CategsensibilisationRow(data);
}

class CategsensibilisationRow extends SupabaseDataRow {
  CategsensibilisationRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => CategsensibilisationTable();

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);

  String get name => getField<String>('name')!;
  set name(String value) => setField<String>('name', value);

  String? get image => getField<String>('image');
  set image(String? value) => setField<String>('image', value);

  String? get user => getField<String>('user');
  set user(String? value) => setField<String>('user', value);
}
