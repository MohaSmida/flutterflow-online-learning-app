import '../database.dart';

class ReclamationTable extends SupabaseTable<ReclamationRow> {
  @override
  String get tableName => 'Reclamation';

  @override
  ReclamationRow createRow(Map<String, dynamic> data) => ReclamationRow(data);
}

class ReclamationRow extends SupabaseDataRow {
  ReclamationRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => ReclamationTable();

  int get id => getField<int>('id')!;
  set id(int value) => setField<int>('id', value);

  DateTime get createdAt => getField<DateTime>('created_at')!;
  set createdAt(DateTime value) => setField<DateTime>('created_at', value);

  String? get type => getField<String>('type');
  set type(String? value) => setField<String>('type', value);

  String? get description => getField<String>('description');
  set description(String? value) => setField<String>('description', value);

  String? get nomUtilisateur => getField<String>('nom_utilisateur');
  set nomUtilisateur(String? value) =>
      setField<String>('nom_utilisateur', value);

  String? get status => getField<String>('Status');
  set status(String? value) => setField<String>('Status', value);
}
