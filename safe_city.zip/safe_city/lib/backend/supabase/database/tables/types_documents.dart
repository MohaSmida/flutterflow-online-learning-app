import '../database.dart';

class TypesDocumentsTable extends SupabaseTable<TypesDocumentsRow> {
  @override
  String get tableName => 'types_documents';

  @override
  TypesDocumentsRow createRow(Map<String, dynamic> data) =>
      TypesDocumentsRow(data);
}

class TypesDocumentsRow extends SupabaseDataRow {
  TypesDocumentsRow(Map<String, dynamic> data) : super(data);

  @override
  SupabaseTable get table => TypesDocumentsTable();

  String get id => getField<String>('id')!;
  set id(String value) => setField<String>('id', value);

  String get libelle => getField<String>('libelle')!;
  set libelle(String value) => setField<String>('libelle', value);
}
