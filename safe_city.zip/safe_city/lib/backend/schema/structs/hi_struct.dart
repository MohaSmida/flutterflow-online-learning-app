// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class HiStruct extends FFFirebaseStruct {
  HiStruct({
    String? name,
    String? image,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _name = name,
        _image = image,
        super(firestoreUtilData);

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  set name(String? val) => _name = val;

  bool hasName() => _name != null;

  // "image" field.
  String? _image;
  String get image => _image ?? '';
  set image(String? val) => _image = val;

  bool hasImage() => _image != null;

  static HiStruct fromMap(Map<String, dynamic> data) => HiStruct(
        name: data['name'] as String?,
        image: data['image'] as String?,
      );

  static HiStruct? maybeFromMap(dynamic data) =>
      data is Map ? HiStruct.fromMap(data.cast<String, dynamic>()) : null;

  Map<String, dynamic> toMap() => {
        'name': _name,
        'image': _image,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'name': serializeParam(
          _name,
          ParamType.String,
        ),
        'image': serializeParam(
          _image,
          ParamType.String,
        ),
      }.withoutNulls;

  static HiStruct fromSerializableMap(Map<String, dynamic> data) => HiStruct(
        name: deserializeParam(
          data['name'],
          ParamType.String,
          false,
        ),
        image: deserializeParam(
          data['image'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'HiStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is HiStruct && name == other.name && image == other.image;
  }

  @override
  int get hashCode => const ListEquality().hash([name, image]);
}

HiStruct createHiStruct({
  String? name,
  String? image,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    HiStruct(
      name: name,
      image: image,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

HiStruct? updateHiStruct(
  HiStruct? hi, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    hi
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addHiStructData(
  Map<String, dynamic> firestoreData,
  HiStruct? hi,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (hi == null) {
    return;
  }
  if (hi.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields = !forFieldValue && hi.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final hiData = getHiFirestoreData(hi, forFieldValue);
  final nestedData = hiData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = hi.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getHiFirestoreData(
  HiStruct? hi, [
  bool forFieldValue = false,
]) {
  if (hi == null) {
    return {};
  }
  final firestoreData = mapToFirestore(hi.toMap());

  // Add any Firestore field values
  hi.firestoreUtilData.fieldValues.forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getHiListFirestoreData(
  List<HiStruct>? his,
) =>
    his?.map((e) => getHiFirestoreData(e, true)).toList() ?? [];
