// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class PdfFileStruct extends FFFirebaseStruct {
  PdfFileStruct({
    String? nameA,
    String? link,
    String? category,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _nameA = nameA,
        _link = link,
        _category = category,
        super(firestoreUtilData);

  // "nameA" field.
  String? _nameA;
  String get nameA => _nameA ?? '';
  set nameA(String? val) => _nameA = val;

  bool hasNameA() => _nameA != null;

  // "link" field.
  String? _link;
  String get link => _link ?? '';
  set link(String? val) => _link = val;

  bool hasLink() => _link != null;

  // "category" field.
  String? _category;
  String get category => _category ?? '';
  set category(String? val) => _category = val;

  bool hasCategory() => _category != null;

  static PdfFileStruct fromMap(Map<String, dynamic> data) => PdfFileStruct(
        nameA: data['nameA'] as String?,
        link: data['link'] as String?,
        category: data['category'] as String?,
      );

  static PdfFileStruct? maybeFromMap(dynamic data) =>
      data is Map ? PdfFileStruct.fromMap(data.cast<String, dynamic>()) : null;

  Map<String, dynamic> toMap() => {
        'nameA': _nameA,
        'link': _link,
        'category': _category,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'nameA': serializeParam(
          _nameA,
          ParamType.String,
        ),
        'link': serializeParam(
          _link,
          ParamType.String,
        ),
        'category': serializeParam(
          _category,
          ParamType.String,
        ),
      }.withoutNulls;

  static PdfFileStruct fromSerializableMap(Map<String, dynamic> data) =>
      PdfFileStruct(
        nameA: deserializeParam(
          data['nameA'],
          ParamType.String,
          false,
        ),
        link: deserializeParam(
          data['link'],
          ParamType.String,
          false,
        ),
        category: deserializeParam(
          data['category'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'PdfFileStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is PdfFileStruct &&
        nameA == other.nameA &&
        link == other.link &&
        category == other.category;
  }

  @override
  int get hashCode => const ListEquality().hash([nameA, link, category]);
}

PdfFileStruct createPdfFileStruct({
  String? nameA,
  String? link,
  String? category,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    PdfFileStruct(
      nameA: nameA,
      link: link,
      category: category,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

PdfFileStruct? updatePdfFileStruct(
  PdfFileStruct? pdfFile, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    pdfFile
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addPdfFileStructData(
  Map<String, dynamic> firestoreData,
  PdfFileStruct? pdfFile,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (pdfFile == null) {
    return;
  }
  if (pdfFile.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && pdfFile.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final pdfFileData = getPdfFileFirestoreData(pdfFile, forFieldValue);
  final nestedData = pdfFileData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = pdfFile.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getPdfFileFirestoreData(
  PdfFileStruct? pdfFile, [
  bool forFieldValue = false,
]) {
  if (pdfFile == null) {
    return {};
  }
  final firestoreData = mapToFirestore(pdfFile.toMap());

  // Add any Firestore field values
  pdfFile.firestoreUtilData.fieldValues.forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getPdfFileListFirestoreData(
  List<PdfFileStruct>? pdfFiles,
) =>
    pdfFiles?.map((e) => getPdfFileFirestoreData(e, true)).toList() ?? [];
