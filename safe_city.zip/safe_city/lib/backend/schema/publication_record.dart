import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class PublicationRecord extends FirestoreRecord {
  PublicationRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "contenu" field.
  String? _contenu;
  String get contenu => _contenu ?? '';
  bool hasContenu() => _contenu != null;

  // "datePublication" field.
  DateTime? _datePublication;
  DateTime? get datePublication => _datePublication;
  bool hasDatePublication() => _datePublication != null;

  // "photo" field.
  String? _photo;
  String get photo => _photo ?? '';
  bool hasPhoto() => _photo != null;

  // "forumId" field.
  DocumentReference? _forumId;
  DocumentReference? get forumId => _forumId;
  bool hasForumId() => _forumId != null;

  // "type" field.
  String? _type;
  String get type => _type ?? '';
  bool hasType() => _type != null;

  void _initializeFields() {
    _contenu = snapshotData['contenu'] as String?;
    _datePublication = snapshotData['datePublication'] as DateTime?;
    _photo = snapshotData['photo'] as String?;
    _forumId = snapshotData['forumId'] as DocumentReference?;
    _type = snapshotData['type'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('publication');

  static Stream<PublicationRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => PublicationRecord.fromSnapshot(s));

  static Future<PublicationRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => PublicationRecord.fromSnapshot(s));

  static PublicationRecord fromSnapshot(DocumentSnapshot snapshot) =>
      PublicationRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static PublicationRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      PublicationRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'PublicationRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is PublicationRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createPublicationRecordData({
  String? contenu,
  DateTime? datePublication,
  String? photo,
  DocumentReference? forumId,
  String? type,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'contenu': contenu,
      'datePublication': datePublication,
      'photo': photo,
      'forumId': forumId,
      'type': type,
    }.withoutNulls,
  );

  return firestoreData;
}

class PublicationRecordDocumentEquality implements Equality<PublicationRecord> {
  const PublicationRecordDocumentEquality();

  @override
  bool equals(PublicationRecord? e1, PublicationRecord? e2) {
    return e1?.contenu == e2?.contenu &&
        e1?.datePublication == e2?.datePublication &&
        e1?.photo == e2?.photo &&
        e1?.forumId == e2?.forumId &&
        e1?.type == e2?.type;
  }

  @override
  int hash(PublicationRecord? e) => const ListEquality()
      .hash([e?.contenu, e?.datePublication, e?.photo, e?.forumId, e?.type]);

  @override
  bool isValidKey(Object? o) => o is PublicationRecord;
}
