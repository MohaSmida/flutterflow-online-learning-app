import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ReclamationsRecord extends FirestoreRecord {
  ReclamationsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "id" field.
  String? _id;
  String get id => _id ?? '';
  bool hasId() => _id != null;

  // "user_id" field.
  String? _userId;
  String get userId => _userId ?? '';
  bool hasUserId() => _userId != null;

  // "type" field.
  String? _type;
  String get type => _type ?? '';
  bool hasType() => _type != null;

  // "description" field.
  String? _description;
  String get description => _description ?? '';
  bool hasDescription() => _description != null;

  // "status" field.
  String? _status;
  String get status => _status ?? '';
  bool hasStatus() => _status != null;

  // "created_at" field.
  DateTime? _createdAt;
  DateTime? get createdAt => _createdAt;
  bool hasCreatedAt() => _createdAt != null;

  // "updated_at" field.
  DateTime? _updatedAt;
  DateTime? get updatedAt => _updatedAt;
  bool hasUpdatedAt() => _updatedAt != null;

  // "cordination" field.
  String? _cordination;
  String get cordination => _cordination ?? '';
  bool hasCordination() => _cordination != null;

  void _initializeFields() {
    _id = snapshotData['id'] as String?;
    _userId = snapshotData['user_id'] as String?;
    _type = snapshotData['type'] as String?;
    _description = snapshotData['description'] as String?;
    _status = snapshotData['status'] as String?;
    _createdAt = snapshotData['created_at'] as DateTime?;
    _updatedAt = snapshotData['updated_at'] as DateTime?;
    _cordination = snapshotData['cordination'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Reclamations');

  static Stream<ReclamationsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ReclamationsRecord.fromSnapshot(s));

  static Future<ReclamationsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ReclamationsRecord.fromSnapshot(s));

  static ReclamationsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ReclamationsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ReclamationsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ReclamationsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ReclamationsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ReclamationsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createReclamationsRecordData({
  String? id,
  String? userId,
  String? type,
  String? description,
  String? status,
  DateTime? createdAt,
  DateTime? updatedAt,
  String? cordination,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'id': id,
      'user_id': userId,
      'type': type,
      'description': description,
      'status': status,
      'created_at': createdAt,
      'updated_at': updatedAt,
      'cordination': cordination,
    }.withoutNulls,
  );

  return firestoreData;
}

class ReclamationsRecordDocumentEquality
    implements Equality<ReclamationsRecord> {
  const ReclamationsRecordDocumentEquality();

  @override
  bool equals(ReclamationsRecord? e1, ReclamationsRecord? e2) {
    return e1?.id == e2?.id &&
        e1?.userId == e2?.userId &&
        e1?.type == e2?.type &&
        e1?.description == e2?.description &&
        e1?.status == e2?.status &&
        e1?.createdAt == e2?.createdAt &&
        e1?.updatedAt == e2?.updatedAt &&
        e1?.cordination == e2?.cordination;
  }

  @override
  int hash(ReclamationsRecord? e) => const ListEquality().hash([
        e?.id,
        e?.userId,
        e?.type,
        e?.description,
        e?.status,
        e?.createdAt,
        e?.updatedAt,
        e?.cordination
      ]);

  @override
  bool isValidKey(Object? o) => o is ReclamationsRecord;
}
