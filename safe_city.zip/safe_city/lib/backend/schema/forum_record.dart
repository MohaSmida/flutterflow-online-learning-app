import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ForumRecord extends FirestoreRecord {
  ForumRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "nom" field.
  String? _nom;
  String get nom => _nom ?? '';
  bool hasNom() => _nom != null;

  // "dateCreation" field.
  DateTime? _dateCreation;
  DateTime? get dateCreation => _dateCreation;
  bool hasDateCreation() => _dateCreation != null;

  // "description" field.
  String? _description;
  String get description => _description ?? '';
  bool hasDescription() => _description != null;

  void _initializeFields() {
    _nom = snapshotData['nom'] as String?;
    _dateCreation = snapshotData['dateCreation'] as DateTime?;
    _description = snapshotData['description'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('forum');

  static Stream<ForumRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ForumRecord.fromSnapshot(s));

  static Future<ForumRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ForumRecord.fromSnapshot(s));

  static ForumRecord fromSnapshot(DocumentSnapshot snapshot) => ForumRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ForumRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ForumRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ForumRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ForumRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createForumRecordData({
  String? nom,
  DateTime? dateCreation,
  String? description,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'nom': nom,
      'dateCreation': dateCreation,
      'description': description,
    }.withoutNulls,
  );

  return firestoreData;
}

class ForumRecordDocumentEquality implements Equality<ForumRecord> {
  const ForumRecordDocumentEquality();

  @override
  bool equals(ForumRecord? e1, ForumRecord? e2) {
    return e1?.nom == e2?.nom &&
        e1?.dateCreation == e2?.dateCreation &&
        e1?.description == e2?.description;
  }

  @override
  int hash(ForumRecord? e) =>
      const ListEquality().hash([e?.nom, e?.dateCreation, e?.description]);

  @override
  bool isValidKey(Object? o) => o is ForumRecord;
}
