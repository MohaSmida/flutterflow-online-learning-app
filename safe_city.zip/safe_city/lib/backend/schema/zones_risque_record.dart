import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ZonesRisqueRecord extends FirestoreRecord {
  ZonesRisqueRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "nom" field.
  String? _nom;
  String get nom => _nom ?? '';
  bool hasNom() => _nom != null;

  // "description" field.
  String? _description;
  String get description => _description ?? '';
  bool hasDescription() => _description != null;

  // "niveau" field.
  String? _niveau;
  String get niveau => _niveau ?? '';
  bool hasNiveau() => _niveau != null;

  // "position" field.
  LatLng? _position;
  LatLng? get position => _position;
  bool hasPosition() => _position != null;

  // "date_creation" field.
  DateTime? _dateCreation;
  DateTime? get dateCreation => _dateCreation;
  bool hasDateCreation() => _dateCreation != null;

  void _initializeFields() {
    _nom = snapshotData['nom'] as String?;
    _description = snapshotData['description'] as String?;
    _niveau = snapshotData['niveau'] as String?;
    _position = snapshotData['position'] as LatLng?;
    _dateCreation = snapshotData['date_creation'] as DateTime?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('zones_risque');

  static Stream<ZonesRisqueRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ZonesRisqueRecord.fromSnapshot(s));

  static Future<ZonesRisqueRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ZonesRisqueRecord.fromSnapshot(s));

  static ZonesRisqueRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ZonesRisqueRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ZonesRisqueRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ZonesRisqueRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ZonesRisqueRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ZonesRisqueRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createZonesRisqueRecordData({
  String? nom,
  String? description,
  String? niveau,
  LatLng? position,
  DateTime? dateCreation,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'nom': nom,
      'description': description,
      'niveau': niveau,
      'position': position,
      'date_creation': dateCreation,
    }.withoutNulls,
  );

  return firestoreData;
}

class ZonesRisqueRecordDocumentEquality implements Equality<ZonesRisqueRecord> {
  const ZonesRisqueRecordDocumentEquality();

  @override
  bool equals(ZonesRisqueRecord? e1, ZonesRisqueRecord? e2) {
    return e1?.nom == e2?.nom &&
        e1?.description == e2?.description &&
        e1?.niveau == e2?.niveau &&
        e1?.position == e2?.position &&
        e1?.dateCreation == e2?.dateCreation;
  }

  @override
  int hash(ZonesRisqueRecord? e) => const ListEquality()
      .hash([e?.nom, e?.description, e?.niveau, e?.position, e?.dateCreation]);

  @override
  bool isValidKey(Object? o) => o is ZonesRisqueRecord;
}
