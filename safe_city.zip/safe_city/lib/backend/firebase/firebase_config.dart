import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyA3x60259rkCQaetd6U8pWjQmcbOpIja8I",
            authDomain: "artclubisims-67c33.firebaseapp.com",
            projectId: "artclubisims-67c33",
            storageBucket: "artclubisims-67c33.firebasestorage.app",
            messagingSenderId: "544217555729",
            appId: "1:544217555729:web:d4a884d4798fa7f88362b0",
            measurementId: "G-TM5V763V7G"));
  } else {
    await Firebase.initializeApp();
  }
}
