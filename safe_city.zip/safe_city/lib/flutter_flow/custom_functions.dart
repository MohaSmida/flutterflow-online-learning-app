import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/auth/supabase_auth/auth_util.dart';

double convertLat(LatLng? coords) {
  return coords?.latitude ?? 0.0;
}

double convertLong(LatLng coords) {
  return coords?.longitude ?? 0.0;
}

LatLng flipCoords(List<String> coordinates) {
  double longtitude = double.parse(coordinates[0]);
  double latitude = double.parse(coordinates[1]);

  LatLng latLng = LatLng(latitude, longtitude);
  return latLng;
}

LatLng convertLocation(
  double lat,
  double long,
) {
  return LatLng(lat, long);
}

double? rating(List<int>? avgrating) {
  if (avgrating == null || avgrating.isEmpty) {
    double sum1 = 0;
    double sum2 = double.parse(sum1.toStringAsFixed(1));
    return sum2;
  }

  int sum = 0;
  for (int note in avgrating) {
    sum += note;
  }
  double averageRating1 = sum / avgrating.length;
  double roundedAverageRating = double.parse(averageRating1.toStringAsFixed(1));

  return roundedAverageRating;
}
