package com.mycompany.safecity

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
